"""
A collection of test problems for black-box optimization.

"""

from optproblems.base import *

__version__ = "1.2"
